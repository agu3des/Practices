package com.example.lojahortfruit.model


import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.toObject
import com.google.firebase.firestore.toObjects
import kotlinx.coroutines.tasks.await

class FrutaDao {
    private val db = FirebaseFirestore.getInstance()

    suspend fun adicionarFruta(fruta: Fruta) {
        db.collection("frutas")
            .add(fruta)
            .addOnSuccessListener {
                println("Fruta adicionado com sucesso!")
            }
            .addOnFailureListener { e ->
                println("Erro ao adicionar fruta: $e")
            }.await()
    }

    suspend fun listarFrutas(): List<Fruta> {
        var frutas: List<Fruta> = ArrayList<Fruta>()
        db.collection("frutas")
            .get()
            .addOnSuccessListener { result ->
                frutas = result.toObjects<Fruta>()
            }
            .addOnFailureListener { e ->
                println("Erro ao listar frutas: $e")
            }.await()
        return frutas
    }

    suspend fun remover(fruta: Fruta) {
        db.collection("frutas")
            .document(fruta.id)
            .delete()
            .addOnSuccessListener { result ->
                println("Fruta adicionado com sucesso!")
            }
            .addOnFailureListener { e ->
                println("Erro ao remover o frutas {fruta.toString()}: $e")
            }.await()
    }

}