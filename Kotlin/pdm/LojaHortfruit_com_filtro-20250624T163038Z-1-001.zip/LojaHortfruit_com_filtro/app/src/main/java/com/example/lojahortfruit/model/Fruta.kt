package com.example.lojahortfruit.model

import com.google.firebase.firestore.DocumentId

data class Fruta(var nome: String, var preco: Double) {
    @DocumentId
    var id: String = ""
    constructor() : this("", 0.0)
}